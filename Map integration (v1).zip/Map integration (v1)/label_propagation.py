def run_label_propagation(file_path="datagrid_1.csv"):
    import pandas as pd
    import networkx as nx
    import numpy as np
    from sklearn.semi_supervised import LabelPropagation
    from sklearn.model_selection import train_test_split
    from sklearn.metrics import accuracy_score, confusion_matrix
    import seaborn as sns
    import matplotlib.pyplot as plt

    # Step 1: Load the dataset
    data = pd.read_csv(file_path)

    # Step 2: Build the graph
    G = nx.Graph()
    for idx, row in data.iterrows():
        lat, lon = row['latitude'], row['longitude']
        pos_occurrence = row['positiveOccurrence']
        node = (lat, lon)
        G.add_node(node,
                   tg=row['tg'], tx=row['tx'], tn=row['tn'],
                   hu=row['hu'], rr=row['rr'],
                   soilType=row['soilType'], pH=row['pH_CaCl2'],
                   soil_moisture=row['soil_moisture'],
                   positiveOccurrence=pos_occurrence)

    # Add edges based on spatial proximity
    for node in G.nodes:
        lat, lon = node
        neighbors = [
            (lat + 0.1, lon), (lat - 0.1, lon), (lat, lon + 0.1), (lat, lon - 0.1),
            (lat + 0.1, lon + 0.1), (lat + 0.1, lon - 0.1), (lat - 0.1, lon + 0.1), (lat - 0.1, lon - 0.1)
        ]
        for neighbor in neighbors:
            if neighbor in G.nodes:
                G.add_edge(node, neighbor)

    # Step 3: Prepare feature matrix and labels
    X = np.array([
        [data['tg'], data['tx'], data['tn'], data['hu'], data['rr'],
         data['soilType'], data['pH_CaCl2'], data['soil_moisture']]
        for node, data in G.nodes(data=True)
    ])
    y = np.array([1 if data['positiveOccurrence'] > 0 else 0 for node, data in G.nodes(data=True)])

    # Validate data
    assert X.size > 0, "Feature matrix X is empty"
    assert y.size > 0, "Labels y are empty"
    assert not np.isnan(X).any(), "Feature matrix X contains NaN values"
    assert not np.isnan(y).any(), "Labels y contain NaN values"

    # Split nodes for training and testing
    train_indices, test_indices = train_test_split(range(len(X)), test_size=0.2, stratify=y)
    y_train = np.copy(y)
    y_train[test_indices] = -1  # Mark test data as unlabeled for label propagation

    # Step 4: Fit the Label Propagation model
    label_prop_model = LabelPropagation(max_iter=1000, kernel='rbf')
    label_prop_model.fit(X, y_train)

    # Step 5: Return predictions and graph nodes
    predicted_labels = label_prop_model.transduction_
    return {node: label for node, label in zip(G.nodes, predicted_labels)}, list(G.nodes)
