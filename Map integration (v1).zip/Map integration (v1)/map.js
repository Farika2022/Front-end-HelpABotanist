// Assuming you have a map instance set up using Leaflet.js
map.on('click', function (event) {
    // Get the latitude and longitude of the clicked location
    const { lat, lng } = event.latlng;

    // Assuming the user selects a plant from a dropdown menu
    const selectedPlant = document.getElementById("plant-select").value;

    // Send the data to the backend
    fetch('/predict', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            latitude: lat,
            longitude: lng,
            plant: selectedPlant
        }),
    })
    .then(response => response.json())
    .then(data => {
        if (data.error) {
            alert("Error: " + data.error);
        } else {
            alert(`Prediction for ${selectedPlant} at (${lat}, ${lng}): ${data.prediction}`);
        }
    })
    .catch(error => {
        console.error("Error:", error);
        alert("An error occurred while fetching the prediction.");
    });
});
