from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from label import labelpropagation, build_graph, query_location, plot_graph
import pandas as pd
from fastapi.middleware.cors import CORSMiddleware
import matplotlib.pyplot as plt
import numpy as np
from io import BytesIO
from fastapi.responses import StreamingResponse

# Initialize FastAPI
app = FastAPI()

# Allow all origins (you can restrict this to specific origins if needed)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allows all origins (use a list of allowed origins for better security)
    allow_credentials=True,
    allow_methods=["*"],  # Allows all methods (GET, POST, etc.)
    allow_headers=["*"],  # Allows all headers
)

# Path to the CSV file
CSV_FILE_PATH = "datagrid.csv"

# Pydantic model for input data
class PlantData(BaseModel):
    plant: str  # User-selected plant name


# Function to get plant details from the CSV
def get_plant_details_from_csv(file_path: str, plant: str):
    # Read CSV and use the first row as header
    plant_data = pd.read_csv(file_path, header=0)
    #print("CSV Data:", plant_data.head())  # Print the first few rows of the CSV to debug

    # Check if the plant exists in the columns
    if plant not in plant_data.columns:
        raise HTTPException(status_code=404, detail=f"Plant '{plant}' not found in the file.")

    # Get the row corresponding to the plant's data
    plant_details_row = plant_data[plant_data[plant] == 1].iloc[0]  # Get the first match
   # print(f"Plant Details Row: {plant_details_row}")  # Print plant details for debugging

    # Map the columns to the dictionary
    plant_details_dict = {
        'latitude': plant_details_row['latitude'],
        'longitude': plant_details_row['longitude'],
        'tg': plant_details_row['tg'],
        'tx': plant_details_row['tx'],
        'tn': plant_details_row['tn'],
        'hu': plant_details_row['hu'],
        'rr': plant_details_row['rr'],
        'soilType': plant_details_row['soilType'],
        'pH_CaCl2': plant_details_row['pH_CaCl2'],
        'soil_moisture': plant_details_row['soil_moisture'],
        'isTest': plant_details_row['isTest'],
        'predicted': plant_details_row['predicted'] if 'predicted' in plant_details_row else "Unknown"  # Check if 'predicted' exists
    }
    print("get_plant_details_from_csv RUN SUCCESSFULLY !!")
   # print("Mapped Plant Details:", plant_details_dict)  # Debug: Final details dictionary
    return plant_details_dict


# Define the prediction endpoint
@app.post("/predict")
async def predict_location(data: PlantData):
    try:
        # Extract the plant name from the request
        target_plant = data.plant
        print(f"Target plant received: {target_plant}")

        # Retrieve plant details (latitude, longitude, etc.) from the CSV
        plant_details = get_plant_details_from_csv(CSV_FILE_PATH, target_plant)
      
         # Build the graph for the plant
        graph = build_graph(target_plant)
        
        # Perform label propagation to classify plant type at each node
        print("Starting label propagation...")
        graph_finished = labelpropagation(graph, finish_labels=True, use_similarity=True, start_percentage=0.2, interations=100)
        print("Label propagation completed.")

         # Query the label propagation result
        lat = plant_details['latitude']
        lon = plant_details['longitude']
        prediction = query_location(graph_finished, lat, lon)

        if lat is None or lon is None:
            raise HTTPException(status_code=404, detail="Latitude or longitude not found for this plant.")
        
         # Prepare heatmap data
        heatmap_data = [
            {
                "latitude": node.get("original_latitude", node["latitude"]),  # Get original latitude
        "longitude": node.get("original_longitude", node["longitude"]),  # Get original longitude
                "intensity": node["label"][0] if "label" in node and isinstance(node["label"], (list, tuple)) else 0,
            }
            for node in graph_finished.nodes.values()
        ]
        # Validate heatmap data
        valid_heatmap_data = [
            data
            for data in heatmap_data
            if data["latitude"] is not None and data["longitude"] is not None
        ]
       
        if not valid_heatmap_data:
            raise HTTPException(status_code=400, detail="No valid heatmap data to return.")
        
        return {"heatmap": valid_heatmap_data,"prediction": prediction}  # Correctly return the heatmap data
       
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
