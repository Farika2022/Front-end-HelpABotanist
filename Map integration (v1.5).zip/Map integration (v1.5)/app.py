from flask import Flask, request, jsonify
from label_propagation import run_label_propagation

app = Flask(__name__)

# Load predictions globally (you can make this dynamic if needed)
predicted_labels = None
graph_nodes = None


@app.before_first_request
def initialize_model():
    """
    Initialize the label propagation and load the predicted labels.
    This ensures the model is loaded only once when the app starts.
    """
    global predicted_labels, graph_nodes
    try:
        # Run label propagation and get predictions
        predicted_labels, graph_nodes = run_label_propagation(file_path="datagrid_1.csv")
    except Exception as e:
        print(f"Error initializing model: {e}")


@app.route('/predict', methods=['POST'])
def predict():
    """
    Predict the growth suitability for a given location and plant type.
    """
    try:
        # Get the selected map location and plant type from the request
        data = request.json
        latitude = data.get("latitude")
        longitude = data.get("longitude")
        plant = data.get("plant")  # Currently unused, but you can expand the model to use it

        if latitude is None or longitude is None or plant is None:
            return jsonify({"error": "Missing latitude, longitude, or plant information"}), 400

        # Find the closest node to the given latitude and longitude
        closest_node = min(
            graph_nodes,
            key=lambda node: (node[0] - latitude) ** 2 + (node[1] - longitude) ** 2
        )

        # Get the prediction for the closest node
        prediction = predicted_labels.get(closest_node, "Unknown")

        result = "Predicted: Growth Possible" if prediction == 1 else "Predicted: Growth Not Possible"

        return jsonify({"location": (latitude, longitude), "plant": plant, "prediction": result})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


if __name__ == "__main__":
    app.run(debug=True)
