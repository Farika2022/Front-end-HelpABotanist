import pandas as pd
import numpy as np
import networkx as nx
from sklearn.semi_supervised import LabelPropagation
import warnings
import pickle
warnings.filterwarnings("ignore")

# Step 1: Load the dataset
data = pd.read_csv("datagrid.csv")

# Step 2: Process the dataset
G = nx.Graph()

# Add each data point as a node
for idx, row in data.iterrows():
    lat, lon = row['latitude'], row['longitude']
    pos_occurrence = row['positiveOccurrence']
    node = (lat, lon)
    G.add_node(node, positiveOccurrence=pos_occurrence)

# Add edges based on spatial proximity
for node in G.nodes:
    lat, lon = node
    neighbors = [
        (lat + 0.1, lon), (lat - 0.1, lon), (lat, lon + 0.1), (lat, lon - 0.1)
    ]
    for neighbor in neighbors:
        if neighbor in G.nodes:
            G.add_edge(node, neighbor)

# Prepare data for Label Propagation
X = np.array(list(G.nodes))
y = np.array([1 if G.nodes[node]['positiveOccurrence'] > 0 else 0 for node in G.nodes])

# Train Label Propagation model
label_prop_model = LabelPropagation(max_iter=1000, kernel='rbf')
label_prop_model.fit(X, y)

# Retrieve the predictions for all nodes
predicted_labels = label_prop_model.transduction_

# Save the trained model
pickle.dump(label_prop_model,open('model.pkl','wb'))
model=pickle.load(open('model.pkl','rb'))
