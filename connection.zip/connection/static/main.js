const map = L.map("map").setView([56.26392, 9.501785], 7); // Centered on Denmark
L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
  maxZoom: 19,
}).addTo(map);

const predictButton = document.getElementById("predict-button");
const plantSelect = document.getElementById("plant-select");
const locationSelect = document.getElementById("location-select");
const resultText = document.getElementById("result-text");

async function getCoordinatesFromLocation(location) {
  const geocodeUrl = `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(location)}&countrycodes=DK`;
  
  try {
    const response = await fetch(geocodeUrl);
    const data = await response.json();
    if (data.length > 0) {
      const latitude = parseFloat(data[0].lat);
      const longitude = parseFloat(data[0].lon);
      return { latitude, longitude };
    } else {
      return null;
    }
  } catch (error) {
    console.error("Error fetching location:", error);
    return null;
  }
}

locationSelect.addEventListener("change", async () => {
  const location = locationSelect.value;
  const coordinates = await getCoordinatesFromLocation(location);
  if (coordinates) {
    // Zoom to the selected location
    map.setView([coordinates.latitude, coordinates.longitude], 10);  // Zoom level 10 for better view
  } else {
    alert("Location not found!");
  }
});

predictButton.addEventListener("click", async () => {
  const plant = plantSelect.value;
  const location = locationSelect.value;
   // Get coordinates for the selected location
   const coordinates = await getCoordinatesFromLocation(location);

   if (!coordinates) {
     resultText.textContent = "Error: Location not found!";
     return;
   }
 
  const { latitude: lat, longitude: lon } = coordinates; // Extract lat and lon from coordinates
 
  const dataToSend = { plant, location };

  // Serialize the data object to a binary string (using a base64 encoding for simplicity)
 // const encodedData = btoa(unescape(encodeURIComponent(JSON.stringify(dataToSend))));  // Base64 encode
//const encodedData = JSON.stringify(dataToSend);  // No need to encode as base64
  try {
    const response = await fetch("/predict", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: encodedData,  // Send the base64 encoded data
    });

    // Log the response to check what we are getting
    const responseText = await response.text();  // Read the response as text first
    console.log("Response Text:", responseText);  // Log the raw response

    // Try to parse the response as JSON
    try {
      const data = JSON.parse(responseText);
      if (response.ok) {
        const heatmapData = data.heatmapData.map(([lat, lon, intensity]) => [
          lat,
          lon,
          intensity * 15,
        ]);

        const heat = L.heatLayer(heatmapData, { radius: 25 }).addTo(map);
        
        resultText.textContent = `Prediction percentage: ${data.predictionPercentage}%`;
      } else {
        resultText.textContent = `Error: ${data.error}`;
      }
    } catch (jsonError) {
      console.error("Error parsing JSON:", jsonError);
      resultText.textContent = "Error: The response is not valid JSON.";
    }

  } catch (error) {
    resultText.textContent = `Error: ${error.message}`;
  }
});
