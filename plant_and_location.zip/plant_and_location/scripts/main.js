// Initialize map
const map = L.map('map').setView([56.2639, 9.5018], 7);

// Add OpenStreetMap tiles
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  attribution: '© OpenStreetMap contributors',
  maxZoom: 18,
}).addTo(map);

// Initialize heatmap layer (empty at the start)
//let heatLayer = L.heatLayer([], { radius: 25, blur: 15 }).addTo(map);

let selectedMarker;
let selectedPlant = null;
let plantNames = [];  // Array to store plant names from the header row
let markersGroup = L.layerGroup().addTo(map); // Group to manage all markers

// Function to fetch plant data from CSV
async function fetchPlantData() {
  const response = await fetch('data/datagrid.csv');
  const text = await response.text();
  const rows = text.split('\n');

  // Extract header row and plant names
  const headerRow = rows[0].split(',');
  plantNames = headerRow.slice(10).map(name => name.trim());
  console.log("Plant Names:", plantNames);

  // Populate dropdown
  const dropdown = document.getElementById('dropdown');
  dropdown.innerHTML = ''; // Clear previous items
  // Sort the plant names alphabetically 
  plantNames.sort((a, b) => a.localeCompare(b));
  plantNames.forEach(plant => {
      const item = document.createElement('div');
      item.className = 'dropdown-item';
      item.textContent = plant;
      item.dataset.plant = plant;
      dropdown.appendChild(item);
  });

  // Parse CSV data rows
  const data = rows.slice(1).map(row => {
      const values = row.split(',');
      const obj = {};
      headerRow.forEach((key, index) => {
          obj[key.trim()] = values[index] ? values[index].trim() : null;
      });
      return obj;
  });

  console.log("Parsed CSV Data:", data); // Debugging
  return data;
}// Function to map presence value to color
function getColorByPresence(presence) {
  if (presence < 5) return 'red';
  if (presence < 10) return 'orange';
  if (presence < 40) return 'violet';
  if (presence > 50) return 'green';
  return 'blue';  // Default color if above 150
}

// Function to extract lat/lon and add markers with colors
function extractLatLonData(data) {
  const latLonData = [];

  data.forEach(row => {
    const lat = parseFloat(row.latitude);
    const lon = parseFloat(row.longitude);
    const presence = parseInt(row[selectedPlant], 10);

    if (!isNaN(lat) && !isNaN(lon) && !isNaN(presence) && presence >= 1) {
      const color = getColorByPresence(presence);

      const marker = L.circleMarker([lat, lon], {
        color: color,
        fillColor: color,
        fillOpacity: 0.7,
        radius: 8, // Adjust radius if needed
      });

      latLonData.push(marker);
    }
  });

  console.log(`Total valid markers: ${latLonData.length}`);
  return latLonData;
}

// Function to display the markers on the map
function displayMarkers(latLonData) {
  map.eachLayer(layer => {
    if (layer instanceof L.CircleMarker) {
      map.removeLayer(layer);
    }
  });

  latLonData.forEach(marker => {
    marker.addTo(map);
  });
}
function setupSearch(data) {
  const searchButton = document.getElementById('search-button');
  searchButton.addEventListener('click', () => {
      if (!selectedPlant) {
          alert('Please select a plant.');
          return;
      }
         // Filter data for the selected plant with presence >= 1
      const filteredData = data.filter(row => {
          const presence = parseInt(row[selectedPlant], 10); // Parse presence value
           console.log(`Plant: ${selectedPlant}, Presence: ${presence}`);
          return !isNaN(presence) && presence >= 1;
      });

      console.log("Filtered Data for Plant:", filteredData); // Debugging
      
      
      // Count the number of valid presences
    const presenceCount = filteredData.length;

     // Update the prediction-result message
     const resultElement = document.getElementById('prediction-result');
     //resultElement.textContent = `Number of presence records for ${selectedPlant}: ${presenceCount}`;
     resultElement.innerHTML = `Number of presence records for <strong>${selectedPlant}</strong>: <strong>${presenceCount}</strong>`;
    // Extract lat/lon data and update heatmap
      const latLonData = extractLatLonData(filteredData);
      if (latLonData.length > 0) {
          addMarkers(latLonData);
          heatLayer.setLatLngs(latLonData);// For dots
          // heatLayer.setLatLngs(latLonData); // For heatmap (if applicable)
          map.fitBounds(latLonData);
      }   else {
          alert(`No valid data found for ${selectedPlant}.`);
          clearMarkers(); // Clear markers if no data
      }
  });
}

// Function to extract latitudes and longitudes and other data from CSV
function extractLatLonData(data) {
  const latLonData = [];
  data.forEach(row => {
      const lat = parseFloat(row.latitude);
      const lon = parseFloat(row.longitude);
      const presence = parseInt(row[selectedPlant], 10);
       // Debugging: log each entry
       console.log(`Lat: ${lat}, Lon: ${lon}, Plant: ${row[selectedPlant]}`);
       // Debugging: log each entry
       if (!isNaN(lat) && !isNaN(lon) && !isNaN(presence) && presence >= 1) {
        latLonData.push([lat, lon, presence]); // Add presence to the data
      
      }
    });
  
    // Debugging: log total lat/lon pairs
    console.log(`Total valid lat/lon pairs: ${latLonData.length}`);
    return latLonData;
  }
   // Add markers to the map for the selected plant
function addMarkers(latLonData) {
  clearMarkers(); // Clear existing markers
  latLonData.forEach(([lat, lon, presence]) => {
    const color = getColorByPresence(presence); // Get the color based on presence

    const marker = L.circleMarker([lat, lon], {
      radius: 5,
      color: color,
      fillColor: color,
      fillOpacity: 0.7,
    }).addTo(markersGroup);
     // Bind a popup to the marker with latitude, longitude, and presence
     marker.bindPopup(`
      <strong>Location:</strong><br>
      Latitude: ${lat}<br>
      Longitude: ${lon}<br>
      Presence: ${presence}
    `);

  });
}

// Clear all markers from the map
function clearMarkers() {
  markersGroup.clearLayers();
}
// Initialize dropdown search functionality
function setupDropdown() {
  const searchInput = document.getElementById('search-input');
  const dropdown = document.getElementById('dropdown');

  // Show dropdown on focus
  searchInput.addEventListener('focus', () => {
    dropdown.classList.add('show');
  });

  // Filter dropdown based on user input
  searchInput.addEventListener('input', (e) => {
    const query = e.target.value.toLowerCase();
    Array.from(dropdown.children).forEach(item => {
      item.style.display = item.textContent.toLowerCase().includes(query) ? 'block' : 'none';
    });
  });

  // Handle plant selection from dropdown
  dropdown.addEventListener('click', (e) => {
    if (e.target.classList.contains('dropdown-item')) {
      selectedPlant = e.target.dataset.plant;
      searchInput.value = selectedPlant;
      dropdown.classList.remove('show');
    }
  });

  // Hide dropdown when clicking outside
  document.addEventListener('click', (e) => {
    if (!dropdown.contains(e.target) && !searchInput.contains(e.target)) {
      dropdown.classList.remove('show');
    }
  });
}

// Fetch and display plant data, latitudes, longitudes, and heatmap
async function initializeData() {
  const data = await fetchPlantData(); // Fetch and parse CSV
  setupDropdown(); // Setup dropdown functionality
  setupSearch(data); // Setup search and heatmap rendering
}
// Initialize the app with data
initializeData();
