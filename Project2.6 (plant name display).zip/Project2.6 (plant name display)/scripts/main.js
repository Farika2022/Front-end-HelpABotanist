// Initialize map
const map = L.map('map').setView([56.2639, 9.5018], 7);

// Add OpenStreetMap tiles
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  attribution: '© OpenStreetMap contributors',
  maxZoom: 18,
}).addTo(map);

let selectedMarker;
let selectedPlant = null;
let plantNames = [];  // Array to store plant names from the header row

// Initialize the heatLayer (empty at the start)
let heatLayer = L.layerGroup().addTo(map);

// Function to fetch plant data from CSV
async function fetchPlantData() {
  const response = await fetch('data/datagrid.csv');
  const text = await response.text();
  const rows = text.split('\n');

  // Get the first row (header row)
  const headerRow = rows[0].split(',');
  
  console.log("Header Row:", headerRow); // Debugging: log the header row
  
  // Extract plant names from column 11 onwards (index 10 onward)
  plantNames = headerRow.slice(10); // From the 11th column (index 10)

  // Debugging: check the plant names array
  console.log("Extracted Plant Names:", plantNames); 

  // Populate dropdown dynamically with plant species from the 11th column onward
  const dropdown = document.getElementById('dropdown');
  if (plantNames.length === 0) {
    console.error("No plant names found!"); // Debugging: log if no plant names
  }

  plantNames.forEach((plant) => {
    const item = document.createElement('div');
    item.className = 'dropdown-item';
    item.textContent = plant;  // Use the plant name from the header
    item.dataset.plant = plant;
    dropdown.appendChild(item);
  });
}

// Dropdown functionality for plant search
const searchInput = document.getElementById('search-input');
const dropdown = document.getElementById('dropdown');

// Ensure dropdown visibility on focus
searchInput.addEventListener('focus', () => {
  dropdown.classList.add('show');
});

searchInput.addEventListener('input', (e) => {
  const query = e.target.value.toLowerCase();
  console.log("User input:", query); // Debugging: log user input
  Array.from(dropdown.children).forEach((item) => {
    item.style.display = item.textContent.toLowerCase().includes(query) ? 'block' : 'none';
  });
});

dropdown.addEventListener('click', (e) => {
  if (e.target.classList.contains('dropdown-item')) {
    selectedPlant = e.target.dataset.plant;
    searchInput.value = selectedPlant;
    dropdown.classList.remove('show');
    document.getElementById('prediction-result').textContent = `Plant selected: ${selectedPlant}`;
  }
});

// Function to extract latitudes and longitudes and other data from CSV
async function extractLatLongData() {
  const response = await fetch('data/datagrid.csv');
  const text = await response.text();
  const rows = text.split('\n');

  // Assuming the first row is the header
  const headerRow = rows[0].split(',');

  // Extract latitude and longitude columns based on the header
  const latIndex = headerRow.indexOf('latitude');
  const lonIndex = headerRow.indexOf('longitude');
  
  if (latIndex === -1 || lonIndex === -1) {
    console.error("Latitude or longitude columns are missing!");
    return;
  }

  // Extracting latitudes, longitudes, and the corresponding plant data
  const latitudes = [];
  const longitudes = [];
  const plantData = [];

  rows.slice(1).forEach((row) => {
    const cols = row.split(',');

    const latitude = parseFloat(cols[latIndex]);
    const longitude = parseFloat(cols[lonIndex]);

    if (!isNaN(latitude) && !isNaN(longitude)) {
      latitudes.push(latitude);
      longitudes.push(longitude);

      // Store other plant data (optional)
      plantData.push(cols.slice(10));  // Store data from columns 11 onward (plant data)
    }
  });

  // Displaying the extracted latitudes and longitudes
  console.log("Latitudes:", latitudes);
  console.log("Longitudes:", longitudes);

  return { latitudes, longitudes, plantData };
}

// Function to plot heatmap data
function plotHeatmap(latitudes, longitudes) {
  const heatData = latitudes.map((lat, index) => [lat, longitudes[index]]);

  heatLayer.setLatLngs(heatData);
  heatLayer.addTo(map);
}

// Fetch and display plant data, latitudes, longitudes, and heatmap
async function initializeData() {
  // Fetch the CSV data
  await fetchPlantData();
  const { latitudes, longitudes, plantData } = await extractLatLongData();

  // Plot the heatmap with the latitudes and longitudes
  plotHeatmap(latitudes, longitudes);
}

// Initialize the app with data
initializeData();
