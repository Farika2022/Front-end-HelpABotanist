// Initialize map
const map = L.map('map').setView([56.2639, 9.5018], 7);

// Add OpenStreetMap tiles
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  attribution: '© OpenStreetMap contributors',
  maxZoom: 18,
}).addTo(map);

let selectedMarker;
let selectedPlant = null;

// Initialize the heatLayer (empty at the start)
let heatLayer = L.layerGroup().addTo(map);

// Dropdown functionality for plant search
const searchInput = document.getElementById('search-input');
const dropdown = document.getElementById('dropdown');

searchInput.addEventListener('focus', () => dropdown.classList.add('show'));
searchInput.addEventListener('input', (e) => {
  const query = e.target.value.toLowerCase();
  Array.from(dropdown.children).forEach((item) => {
    item.style.display = item.textContent.toLowerCase().includes(query) ? 'block' : 'none';
  });
});

dropdown.addEventListener('click', (e) => {
  if (e.target.classList.contains('dropdown-item')) {
    selectedPlant = e.target.dataset.plant;
    searchInput.value = selectedPlant;
    dropdown.classList.remove('show');
    document.getElementById('prediction-result').textContent = `Plant selected: ${selectedPlant}`;
  }
});

// Geocoding for location input (Dropdown for location search)
const locationInput = document.getElementById('location-input');
const locationDropdown = document.createElement('div');
locationDropdown.className = 'dropdown-content';
locationInput.parentNode.appendChild(locationDropdown);

// Function to fetch geocoding data for a location
async function geocodeLocation(location) {
  const url = `https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(
    location
  )}&format=json&addressdetails=1&countrycodes=dk`;
  try {
    const response = await fetch(url);
    if (!response.ok) throw new Error("Failed to fetch geocoding data.");
    const data = await response.json();
    return data;
  } catch (error) {
    console.error(error);
    alert("Unable to find the location. Please try again.");
    return [];
  }
}

// Function to update location dropdown
async function updateLocationDropdown(query) {
  const results = await geocodeLocation(query);
  locationDropdown.innerHTML = '';
  results.forEach(({ display_name, lat, lon }) => {
    const item = document.createElement('div');
    item.className = 'dropdown-item';
    item.textContent = display_name;
    item.dataset.lat = lat;
    item.dataset.lon = lon;
    locationDropdown.appendChild(item);
  });

  locationDropdown.classList.add('show');
}

// Add event listener to location input for dropdown
locationInput.addEventListener('input', (e) => {
  const query = e.target.value.trim();
  if (query) {
    updateLocationDropdown(query);
  } else {
    locationDropdown.classList.remove('show');
  }
});

// Handle location dropdown item click
locationDropdown.addEventListener('click', (e) => {
  if (e.target.classList.contains('dropdown-item')) {
    const lat = parseFloat(e.target.dataset.lat);
    const lon = parseFloat(e.target.dataset.lon);
    const displayName = e.target.textContent;

    locationInput.value = displayName;
    locationDropdown.classList.remove('show');

    showLocationOnMap(lat, lon, displayName);
  }
});

// Function to display location on map and simulate heat map
function showLocationOnMap(lat, lon, displayName) {
  // Set marker on map
  if (selectedMarker) {
    selectedMarker.setLatLng([lat, lon]);
  } else {
    selectedMarker = L.marker([lat, lon]).addTo(map);
  }

  // Center map on location
  map.setView([lat, lon], 10);

  // Simulate probability for plant growth
  const probability = (Math.random() * 100).toFixed(1);

  // Update the result section with location info and probability
  document.getElementById('prediction-result').textContent =
    `Selected location: ${displayName} (Lat: ${lat.toFixed(2)}, Lng: ${lon.toFixed(2)}) - Probability of ${selectedPlant} presence: ${probability}%`;

  // Simulate and display heat map
  updateHeatMap(lat, lon);
}

// Simulate heat map data around a selected location, including nearby regions
function simulateHeatMapData(lat, lon) {
  const heatData = [];
  const radius = 0.05; // Degrees (~5 km)
  for (let i = 0; i < 30; i++) { // Simulating more points for nearby regions
    const randomLat = lat + (Math.random() - 0.5) * radius;
    const randomLon = lon + (Math.random() - 0.5) * radius;
    const intensity = Math.random(); // Random intensity between 0 and 1
    heatData.push([randomLat, randomLon, intensity]);
  }
  return heatData;
}

// Function to update the heatmap based on the selected location and nearby regions
function updateHeatMap(lat, lon) {
  const simulatedData = simulateHeatMapData(lat, lon);

  // Clear the old heatLayer if it exists
  if (map.hasLayer(heatLayer)) {
    map.removeLayer(heatLayer);
  }

  // Get the current zoom level
  const zoom = map.getZoom();

  // Dynamically adjust the radius and blur based on zoom level
  const radius = 25 + zoom * 2;  // The radius will grow with zoom level
  const blur = 15 + zoom;        // The blur will also increase with zoom

  // Define custom color gradient for heatmap
  const customGradient = {
    0.0: 'yellow',    // Low intensity
    0.2: 'orange',    // Medium intensity
    0.5: 'red',       // High intensity
    1.0: 'darkred'    // Maximum intensity
  };

  // Add the new heatLayer with the custom gradient
  heatLayer = L.heatLayer(simulatedData, {
    radius: radius,
    blur: blur,
    gradient: customGradient // Apply custom gradient
  });
  map.addLayer(heatLayer);
}

// Add heatmap legend
function addHeatMapLegend() {
  const legend = L.control({ position: 'bottomright' });

  legend.onAdd = function () {
    const div = L.DomUtil.create('div', 'info legend');
    div.innerHTML = `
      <strong>Heatmap Intensity</strong><br>
      <i style="background: #ff0000; width: 18px; height: 18px; display: inline-block;"></i> High likelihood<br>
      <i style="background: #ffa500; width: 18px; height: 18px; display: inline-block;"></i> Medium likelihood<br>
      <i style="background: #ffff00; width: 18px; height: 18px; display: inline-block;"></i> Low likelihood<br>
    `;
    div.style.padding = '10px';
    div.style.backgroundColor = 'white';
    div.style.border = '1px solid #ccc';
    return div;
  };

  legend.addTo(map);
}

// Initialize legend
addHeatMapLegend();

// Event listener for location input to trigger geocoding and show location
locationInput.addEventListener('keypress', async (e) => {
  if (e.key === 'Enter') {
    e.preventDefault(); // Prevent form submission

    const location = locationInput.value.trim();
    if (!location) {
      alert("Please enter a location.");
      return;
    }

    const results = await geocodeLocation(location);

    if (results.length === 0) {
      alert("Location not found or not in Denmark. Please try again.");
      return;
    }

    const { lat, lon, display_name } = results[0];
    showLocationOnMap(lat, lon, display_name);
  }
});
