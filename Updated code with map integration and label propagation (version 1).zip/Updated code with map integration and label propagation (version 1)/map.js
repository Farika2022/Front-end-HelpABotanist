// map.js
// Create map and set Denmark as the default focus
const map = L.map('map').setView([56.2639, 9.5018], 7); // Denmark center coordinates

// Add OpenStreetMap tile layer
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; OpenStreetMap contributors'
}).addTo(map);

// Elements for displaying user feedback
const locationFeedback = document.getElementById('location-feedback');
const predictionResult = document.getElementById('prediction-result');

// Handle user click on the map
map.on('click', async function (e) {
    const { lat, lng } = e.latlng;

    // Ensure the click is within Denmark bounds
    if (lat >= 54.5 && lat <= 57.8 && lng >= 8 && lng <= 15) {
        locationFeedback.textContent = `Coordinates: Latitude ${lat.toFixed(4)}, Longitude ${lng.toFixed(4)}`;

        try {
            // Call the prediction API
            const response = await fetch('http://127.0.0.1:5000/predict', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ latitude: lat, longitude: lng }),
            });

            if (response.ok) {
                const data = await response.json();
                const plantStatus = data.prediction === 1 ? 'Yes' : 'No';
                predictionResult.textContent = `Can Grow: ${plantStatus}`;
            } else {
                predictionResult.textContent = "Error fetching prediction!";
            }
        } catch (error) {
            predictionResult.textContent = "Failed to connect to the prediction service.";
            console.error("Error:", error);
        }
    } else {
        locationFeedback.textContent = "Selected location is outside Denmark!";
        predictionResult.textContent = "";
    }
});
