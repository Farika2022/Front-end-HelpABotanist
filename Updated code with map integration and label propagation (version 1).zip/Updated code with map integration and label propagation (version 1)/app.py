# app.py
from flask import Flask, request, jsonify
import pandas as pd
import networkx as nx
import numpy as np
from sklearn.semi_supervised import LabelPropagation

# Create Flask App
app = Flask(__name__)

# Load Data and Initialize Model
data = pd.read_csv("datagrid_1.csv")
G = nx.Graph()

# Add Nodes and Edges (same as Cody's script)
for idx, row in data.iterrows():
    lat, lon = row['latitude'], row['longitude']
    pos_occurrence = row['positiveOccurrence']
    node = (lat, lon)
    G.add_node(node,
               tg=row['tg'], tx=row['tx'], tn=row['tn'],
               hu=row['hu'], rr=row['rr'],
               soilType=row['soilType'], pH=row['pH_CaCl2'],
               soil_moisture=row['soil_moisture'],
               positiveOccurrence=pos_occurrence)
for node in G.nodes:
    lat, lon = node
    neighbors = [
        (lat + 0.1, lon), (lat - 0.1, lon), (lat, lon + 0.1), (lat, lon - 0.1),
        (lat + 0.1, lon + 0.1), (lat + 0.1, lon - 0.1), (lat - 0.1, lon + 0.1), (lat - 0.1, lon - 0.1)
    ]
    for neighbor in neighbors:
        if neighbor in G.nodes:
            G.add_edge(node, neighbor)

# Initialize Label Propagation
labels = {node: 1 if data['positiveOccurrence'] > 0 else 0 for node, data in G.nodes(data=True)}
X = np.array(list(G.nodes))
y = np.array([labels[node] for node in G.nodes])
y_train = np.copy(y)
y_train[:] = -1  # Unlabeled data for the model

label_prop_model = LabelPropagation(max_iter=1000, kernel='rbf')
label_prop_model.fit(X, y_train)

# API Endpoint for Predictions
@app.route('/predict', methods=['POST'])
def predict():
    payload = request.json
    lat, lon = payload.get('latitude'), payload.get('longitude')

    # Find the closest node in the graph
    closest_node = min(G.nodes, key=lambda n: (n[0] - lat)**2 + (n[1] - lon)**2)
    prediction = label_prop_model.predict([closest_node])[0]
    return jsonify({"latitude": lat, "longitude": lon, "prediction": int(prediction)})

if __name__ == "__main__":
    app.run(debug=True)
